package com.bitc.team2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Kong1Application {

	public static void main(String[] args) {
		SpringApplication.run(Kong1Application.class, args);
	}

}
