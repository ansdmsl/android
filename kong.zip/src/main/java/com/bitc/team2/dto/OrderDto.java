package com.bitc.team2.dto;

import lombok.Data;

@Data
public class OrderDto {
	
	private int seq;
	private String userAddr;
	private String userAddrDetail;

}


