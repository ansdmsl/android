package com.bitc.team2.dto;

import lombok.Data;

@Data
public class BoardDto {

	private int seq;
	private String boardTitle;
	private String boardContent;
}
