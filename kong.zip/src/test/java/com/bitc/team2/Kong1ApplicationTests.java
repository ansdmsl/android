package com.bitc.team2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Kong1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
